/**
 * Interface for an immutable queue. A Queue is a First In First Out (FIFO) data
 */
public interface Queue<T> {

    /**
     * Adds element at the beginning of the immutable queue, and returns the updated
     * @return the updated queue after adding to the beginning of the queue
     */
    Queue<T> enQueue(T t);

    /**
     * Removes the element from the end of the immutable queue, and returns the
     * updated queue.

     */
    Queue<T> deQueue() throws EmptyQueueException, EmptyStackException;

    /**
     * Returns the head or first element of the queue.

     */
    T head() throws EmptyQueueException, EmptyStackException;

    /**
     * Checks if this queue is empty.
     */
    boolean isEmpty();
}