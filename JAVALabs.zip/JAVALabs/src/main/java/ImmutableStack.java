/**
 * A concrete class that represents an Immutable Stack.
 */
public final class ImmutableStack<T> implements Stack<T> {

    private final T value;
    private final Stack<T> tail;

    /*
    * Private constructor to prevent, implement from the Singleton design pattern.
    * */
    private ImmutableStack(T value, Stack<T> tail) {
        this.value = value;
        this.tail = tail;
    }
    /*
    * Insert new element into the Stack.
    * */
    @Override
    public final Stack<T> push(T e) {
        return new ImmutableStack<>(e, this);
    }

    /*
    * The last element in the Stack
    * */
    @Override
    public final Stack<T> pop() {
        return tail;
    }

    /*
    * Current Stack count
    * */
    @Override
    public final T head() {
        return value;
    }

    /*
    * A flag to determine whether the Stack is empty
    * */
    @Override
    public final boolean isEmpty() {
        return false;
    }

    /*
    * Initialise a new instance empty Stack
    * */
    @SuppressWarnings("rawtypes")
    public static final Stack empty() {
        return EmptyStack.getInstance();
    }

    /**
     * A singleton class that represents an empty Stack.
     */
    private static final class EmptyStack<T> implements Stack<T> {

        @SuppressWarnings("rawtypes")
        private static final EmptyStack instance = new EmptyStack();

        @SuppressWarnings("rawtypes")
        public static final EmptyStack getInstance() {
            return instance;
        }

        @Override
        public final Stack<T> push(T e) {
            return new ImmutableStack<>(e, this);
        }

        @Override
        public final Stack<T> pop() throws EmptyStackException {
            throw new EmptyStackException();
        }

        @Override
        public final T head() throws EmptyStackException {
            throw new EmptyStackException();
        }

        @Override
        public final boolean isEmpty() {
            return true;
        }
    }
}