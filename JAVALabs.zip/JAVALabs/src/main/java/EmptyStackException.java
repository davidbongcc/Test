
/*
* Empty Stack exception class
* */
public class EmptyStackException extends Exception {

    private static final long serialVersionUID = 002;

    public EmptyStackException() {
        super("Empty stack!");
    }
}