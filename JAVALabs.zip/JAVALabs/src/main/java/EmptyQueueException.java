/*
* Empty queue exception class
* */
public class EmptyQueueException extends Exception {

    private static final long serialVersionUID = 001;

    public EmptyQueueException() {
        super("Empty queue!");
    }
}