/**
 * Interface for an immutable stack. A Stack is a Last In First Out (LIFO) data
 */
public interface Stack<T> {

    /**
     * Adds element at the top of the immutable stack, and returns the updated
     * @return the updated stack after adding to the top of the stack
     */
    Stack<T> push(T e);

    /**
     * Removes the element from the top of the immutable stack, and returns the
     * updated stack.
     *
     * @return the updated stack after removing the top element
     * @throws EmptyStackException when stack is empty
     */
    Stack<T> pop() throws EmptyStackException;

    /**
     * Returns the head element or top of the stack. The Stack's current condition
     *
     * @return top element of the stack
     * @throws EmptyStackException when stack is empty
     */
    T head() throws EmptyStackException;

    /**
     * Checks if this stack is empty.
     *
     * @return true when the stack is empty, false otherwise
     */
    boolean isEmpty();
}