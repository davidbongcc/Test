import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.time.Duration;
import java.time.Instant;

import org.junit.jupiter.api.Test;
/*
*  Queue and Immutable unit test class file
* */
public class QueueTest {


    @Test
    void empty_queue_ok() {
        assertNotNull(ImmutableQueue.empty());
    }
}
